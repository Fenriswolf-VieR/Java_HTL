
public class Person {
	private String name;
	
	public Person (String Name) {
		name = Name;
	}

	public String getName() {
		return name;
	}

	public void setName(String Name) {
		name = Name;
	}

}
